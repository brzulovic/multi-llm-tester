import { render, screen, fireEvent } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import App from "./App";

describe("LLM Multi-Tester App", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("renders the main title", () => {
    render(<App />);
    expect(screen.getByText("LLM Multi-Tester")).toBeInTheDocument();
  });

  it("allows changing the API endpoint", () => {
    render(<App />);
    const endpointInput = screen.getByPlaceholderText("http://localhost:4000/v1/chat/completions") as HTMLInputElement;
    fireEvent.change(endpointInput, { target: { value: "http://test-api.com" } });
    expect(endpointInput.value).toBe("http://test-api.com");
  });

  it("allows changing the model list", () => {
    render(<App />);
    const modelListTextarea = screen.getByPlaceholderText(/myGemma3/i) as HTMLTextAreaElement;
    fireEvent.change(modelListTextarea, { target: { value: "gpt-4\ngpt-3.5" } });
    expect(modelListTextarea.value).toBe("gpt-4\ngpt-3.5");
  });

  it("toggles parallel mode", () => {
    render(<App />);
    const parallelCheckbox = screen.getByRole("checkbox") as HTMLInputElement;
    expect(parallelCheckbox.checked).toBe(false);
    
    fireEvent.click(parallelCheckbox);
    expect(parallelCheckbox.checked).toBe(true);
  });

  it("shows parallel count input when parallel mode is active", () => {
    render(<App />);
    const parallelCheckbox = screen.getByRole("checkbox");
    
    // Initially not visible (or not in DOM)
    expect(screen.queryByRole("spinbutton")).not.toBeInTheDocument();
    
    fireEvent.click(parallelCheckbox);
    expect(screen.getByRole("spinbutton")).toBeInTheDocument();
  });

  it("sends custom headers in the fetch request", async () => {
    const mockFetch = vi.fn().mockResolvedValue({
      ok: true,
      json: () => Promise.resolve({ choices: [{ message: { content: "test" } }], usage: {} }),
    });
    (global as any).fetch = mockFetch;

    render(<App />);
    
    const headersTextarea = screen.getByPlaceholderText("x-litellm-api-key: Bearer sk-1234") as HTMLTextAreaElement;
    fireEvent.change(headersTextarea, { target: { value: "Authorization: Bearer my-token\nX-Custom: value" } });
    
    const generateButton = screen.getByText("Generate");
    fireEvent.click(generateButton);

    // Wait for fetch to be called
    await vi.waitFor(() => expect(mockFetch).toHaveBeenCalled());

    const lastCallHeaders = mockFetch.mock.calls[0][1].headers;
    expect(lastCallHeaders["Authorization"]).toBe("Bearer my-token");
    expect(lastCallHeaders["X-Custom"]).toBe("value");
    expect(lastCallHeaders["Content-Type"]).toBe("application/json");
  });

  it("displays DevTools network metrics waterfall after model execution", async () => {
    const mockFetch = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      statusText: "OK",
      json: () => Promise.resolve({
        choices: [{ message: { content: "Sample response from model" } }],
        usage: { prompt_tokens: 15, completion_tokens: 45, total_tokens: 60 }
      }),
    });
    (global as any).fetch = mockFetch;

    render(<App />);

    // Set to 1 model for deterministic testing
    const modelListTextarea = screen.getByPlaceholderText(/myGemma3/i) as HTMLTextAreaElement;
    fireEvent.change(modelListTextarea, { target: { value: "test-model-1" } });

    const generateButton = screen.getByText("Generate");
    fireEvent.click(generateButton);

    // Wait for the DevTools Network Timing Waterfall to be displayed
    expect(await screen.findByText("Network Timing Waterfall")).toBeInTheDocument();

    // Await completion of the request
    expect(await screen.findByText("DevTools Network Timing")).toBeInTheDocument();

    // Check that DevTools Network features are rendered
    expect(screen.getByText("DevTools")).toBeInTheDocument();
    expect(screen.getByText("Queueing")).toBeInTheDocument();
    expect(screen.getByText("Waiting (TTFB)")).toBeInTheDocument();
  });

  it("allows switching between Split, DevTools Network, and Cards view modes", async () => {
    const mockFetch = vi.fn().mockResolvedValue({
      ok: true,
      status: 200,
      statusText: "OK",
      json: () => Promise.resolve({
        choices: [{ message: { content: "Response content" } }],
        usage: { prompt_tokens: 10, completion_tokens: 20, total_tokens: 30 }
      }),
    });
    (global as any).fetch = mockFetch;

    render(<App />);

    const modelListTextarea = screen.getByPlaceholderText(/myGemma3/i) as HTMLTextAreaElement;
    fireEvent.change(modelListTextarea, { target: { value: "test-model-alpha" } });

    const generateButton = screen.getByText("Generate");
    fireEvent.click(generateButton);

    expect(await screen.findByText("DevTools Network Timing")).toBeInTheDocument();

    // Click DevTools Network view mode
    const networkViewBtn = screen.getByRole("button", { name: /DevTools Network/i });
    fireEvent.click(networkViewBtn);

    // Network timing waterfall should be visible
    expect(screen.getByText("Network Timing Waterfall")).toBeInTheDocument();

    // Inspect Breakdown button in card
    const splitBtn = screen.getByRole("button", { name: /Split/i });
    fireEvent.click(splitBtn);

    const inspectBtn = screen.getByRole("button", { name: /Inspect Breakdown/i });
    fireEvent.click(inspectBtn);

    // Full Timing drawer should now be open
    expect(screen.getByText("Resource Scheduling")).toBeInTheDocument();
    expect(screen.getByText("Request sent")).toBeInTheDocument();
  });
});
