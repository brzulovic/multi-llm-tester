/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  Play, 
  Settings, 
  Layers, 
  Zap, 
  Clock, 
  Hash, 
  Terminal, 
  CheckCircle2, 
  AlertCircle, 
  Loader2,
  Cpu,
  RefreshCw,
  Copy,
  Trash2,
  ChevronDown,
  ChevronUp,
  Search,
  Plus,
  X,
  List,
  History,
  Download,
  Upload,
  Calendar,
  ChevronRight,
  Activity,
  BarChart2,
  LayoutGrid,
  Maximize2
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { ModelResult, HistoryEntry } from "./types";
import { NetworkWaterfallPanel } from "./components/NetworkWaterfallPanel";
import { DevToolsTimingDetail } from "./components/DevToolsTimingDetail";

export default function App() {
  const [endpoint, setEndpoint] = useState("http://localhost:4000/v1/chat/completions");
  const [customHeaders, setCustomHeaders] = useState("x-litellm-api-key: Bearer sk-1234");
  const [modelList, setModelList] = useState("myGemma3\nmyGroq\nmyOpenrouter\nollama-glm-5:cloud\nlocal-functiongemma:270m");
  const [prompt, setPrompt] = useState("Describe all your capabilities, including your name and a detailed description of your model architecture and features.");
  const [isParallel, setIsParallel] = useState(false);
  const [parallelCount, setParallelCount] = useState(2);
  const [results, setResults] = useState<ModelResult[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [availableModels, setAvailableModels] = useState<string[]>([]);
  const [isFetchingModels, setIsFetchingModels] = useState(false);
  const [showModelSelector, setShowModelSelector] = useState(false);
  const [modelSearch, setModelSearch] = useState("");
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [viewMode, setViewMode] = useState<"split" | "waterfall" | "cards">("split");
  const [selectedResultId, setSelectedResultId] = useState<string | null>(null);
  const sessionStartTimeRef = useRef<number>(0);

  const [collapsed, setCollapsed] = useState({
    config: false,
    prompt: false,
    history: true
  });

  // Load history from localStorage on mount
  useEffect(() => {
    const savedHistory = localStorage.getItem("llm_tester_history");
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error("Failed to parse history", e);
      }
    }
  }, []);

  // Save history to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("llm_tester_history", JSON.stringify(history));
  }, [history]);

  const toggleSection = (section: keyof typeof collapsed) => {
    setCollapsed(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const fetchModels = async () => {
    setIsFetchingModels(true);
    try {
      // Derive models endpoint from chat completions endpoint
      const modelsUrl = endpoint.replace(/chat\/completions\/?$/, "models");
      
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };

      if (customHeaders.trim()) {
        customHeaders.split("\n").forEach((line) => {
          const [key, ...valueParts] = line.split(":");
          if (key && valueParts.length > 0) {
            headers[key.trim()] = valueParts.join(":").trim();
          }
        });
      }

      const response = await fetch(modelsUrl, { headers });
      if (!response.ok) throw new Error(`Failed to fetch models: ${response.status}`);
      
      const data = await response.json();
      // OpenAI format is { data: [{ id: "model-id", ... }, ...] }
      const models = (data.data || []).map((m: any) => m.id).sort();
      setAvailableModels(models);
      setShowModelSelector(true);
    } catch (err) {
      alert(err instanceof Error ? err.message : "Failed to fetch models");
    } finally {
      setIsFetchingModels(false);
    }
  };

  const addModel = (model: string) => {
    const currentModels = modelList.split("\n").map(m => m.trim()).filter(m => m !== "");
    if (!currentModels.includes(model)) {
      setModelList(prev => prev.trim() ? `${prev}\n${model}` : model);
    }
  };

  const exportHistory = () => {
    const dataStr = JSON.stringify(history, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = `llm-tester-history-${new Date().toISOString().split('T')[0]}.json`;

    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const importHistory = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const imported = JSON.parse(content);
        if (Array.isArray(imported)) {
          setHistory(prev => [...imported, ...prev].slice(0, 100));
          alert("History imported successfully!");
        }
      } catch (err) {
        alert("Failed to import history: Invalid JSON format");
      }
    };
    reader.readAsText(file);
  };

  const loadHistoryEntry = (entry: HistoryEntry) => {
    setPrompt(entry.prompt);
    setEndpoint(entry.endpoint);
    setResults(entry.results);
  };

  const deleteHistoryEntry = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setHistory(prev => prev.filter(h => h.id !== id));
  };

  const generateResults = async () => {
    if (!prompt.trim() || !modelList.trim()) return;

    const models = modelList
      .split("\n")
      .map((m) => m.trim())
      .filter((m) => m !== "");

    if (models.length === 0) return;

    setIsGenerating(true);
    sessionStartTimeRef.current = performance.now();
    const initialResults: ModelResult[] = models.map((model, index) => ({
      id: `${model}-${index}-${Date.now()}`,
      modelName: model,
      status: "idle",
      output: "",
    }));

    setResults(initialResults);

    if (isParallel) {
      await runParallel(initialResults);
    } else {
      await runSequential(initialResults);
    }

    setIsGenerating(false);

    // Save to history after generation is complete
    // We need to get the latest results state, but since we're in an async function
    // that updates state multiple times, we'll use a functional update or a ref
    // For simplicity here, we'll capture the results after a short delay or 
    // better, use a separate effect to detect completion.
  };

  // Effect to save to history when generation finishes
  useEffect(() => {
    if (!isGenerating && results.length > 0 && results.some(r => r.status === 'success' || r.status === 'error')) {
      const newEntry: HistoryEntry = {
        id: `hist-${Date.now()}`,
        timestamp: Date.now(),
        prompt,
        endpoint,
        results: [...results]
      };
      
      setHistory(prev => {
        // Prevent duplicate entries if the results haven't changed (e.g. from a re-render)
        if (prev.length > 0 && prev[0].prompt === newEntry.prompt && JSON.stringify(prev[0].results) === JSON.stringify(newEntry.results)) {
          return prev;
        }
        return [newEntry, ...prev].slice(0, 50); // Keep last 50 entries
      });
    }
  }, [isGenerating]);

  const runSequential = async (initialResults: ModelResult[]) => {
    for (let i = 0; i < initialResults.length; i++) {
      await processModel(initialResults[i].id, initialResults[i].modelName);
    }
  };

  const runParallel = async (initialResults: ModelResult[]) => {
    const queue = [...initialResults];
    const active = new Set<string>();
    const limit = Math.max(1, parallelCount);

    return new Promise<void>((resolve) => {
      const next = async () => {
        if (queue.length === 0 && active.size === 0) {
          resolve();
          return;
        }

        while (queue.length > 0 && active.size < limit) {
          const item = queue.shift()!;
          active.add(item.id);
          
          processModel(item.id, item.modelName).finally(() => {
            active.delete(item.id);
            next();
          });
        }
      };
      next();
    });
  };

  const processModel = async (id: string, modelName: string) => {
    const queueMs = sessionStartTimeRef.current > 0 
      ? Math.max(0, performance.now() - sessionStartTimeRef.current) 
      : 0;

    setResults((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: "pending", startTimeOffsetMs: queueMs } : r))
    );

    const fetchStartTime = performance.now();
    let statusCode = 200;
    let statusText = "OK";

    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
      };

      if (customHeaders.trim()) {
        customHeaders.split("\n").forEach((line) => {
          const [key, ...valueParts] = line.split(":");
          if (key && valueParts.length > 0) {
            headers[key.trim()] = valueParts.join(":").trim();
          }
        });
      }

      const response = await fetch(endpoint, {
        method: "POST",
        headers,
        body: JSON.stringify({
          model: modelName,
          messages: [{ role: "user", content: prompt }],
          stream: false,
        }),
      });

      statusCode = response.status;
      statusText = response.statusText || (response.ok ? "OK" : "Error");
      const ttfbEnd = performance.now();
      const ttfbMs = Math.max(1, ttfbEnd - fetchStartTime);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const downloadStart = performance.now();
      const data = await response.json();
      const downloadEnd = performance.now();
      const downloadMs = Math.max(1, downloadEnd - downloadStart);
      const durationMs = downloadEnd - fetchStartTime;

      const output = data.choices?.[0]?.message?.content || "No output received";
      const usage = data.usage || { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 };
      
      const completionTokens = usage.completion_tokens || 0;
      const promptTokens = usage.prompt_tokens || 0;
      const totalTokens = usage.total_tokens || (promptTokens + completionTokens);
      const tokensPerSecond = completionTokens > 0 ? (completionTokens / (durationMs / 1000)) : 0;

      setResults((prev) =>
        prev.map((r) =>
          r.id === id
            ? {
                ...r,
                status: "success",
                statusCode,
                statusText,
                startTimeOffsetMs: queueMs,
                output,
                metrics: {
                  promptTokens,
                  completionTokens,
                  totalTokens,
                  durationMs,
                  tokensPerSecond,
                  ttfbMs,
                  downloadMs,
                  queueMs,
                  requestSentMs: Math.min(2, Math.round(ttfbMs * 0.05)),
                },
              }
            : r
        )
      );
    } catch (err) {
      const durationMs = Math.max(1, performance.now() - fetchStartTime);
      setResults((prev) =>
        prev.map((r) =>
          r.id === id
            ? {
                ...r,
                status: "error",
                statusCode: statusCode !== 200 ? statusCode : 500,
                statusText: statusText !== "OK" ? statusText : "Error",
                startTimeOffsetMs: queueMs,
                metrics: {
                  promptTokens: 0,
                  completionTokens: 0,
                  totalTokens: 0,
                  durationMs,
                  tokensPerSecond: 0,
                  ttfbMs: durationMs,
                  downloadMs: 0,
                  queueMs,
                  requestSentMs: 1,
                },
                error: err instanceof Error ? err.message : "Unknown error",
              }
            : r
        )
      );
    }
  };

  const clearResults = () => {
    setResults([]);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#1A1A1A] font-sans selection:bg-indigo-100">
      {/* Header */}
      <header className="border-b border-gray-200 bg-white sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-200">
              <Layers className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">LLM Multi-Tester</h1>
              <p className="text-xs text-gray-500 font-medium uppercase tracking-wider">Sequential & Parallel Benchmarking</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-gray-100 rounded-full text-xs font-medium text-gray-600">
              <div className={`w-2 h-2 rounded-full ${isGenerating ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'}`} />
              {isGenerating ? 'Processing...' : 'Ready'}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sidebar Controls */}
        <div className="lg:col-span-4 space-y-6">
          <section className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <button 
              onClick={() => toggleSection('config')}
              className="w-full flex items-center justify-between p-6 text-gray-900 font-semibold hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Settings className="w-4 h-4" />
                <h2>Configuration</h2>
              </div>
              {collapsed.config ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronUp className="w-4 h-4 text-gray-400" />}
            </button>
            
            <AnimatePresence>
              {!collapsed.config && (
                <motion.div 
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="px-6 pb-6 space-y-4 border-t border-gray-50 pt-4"
                >
                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">API Endpoint</label>
                    <div className="relative">
                      <Terminal className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input 
                        type="text" 
                        value={endpoint}
                        onChange={(e) => setEndpoint(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all font-mono"
                        placeholder="http://localhost:4000/v1/chat/completions"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Custom Headers (one per line)</label>
                    <textarea 
                      value={customHeaders}
                      onChange={(e) => setCustomHeaders(e.target.value)}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all min-h-[80px] font-mono leading-relaxed"
                      placeholder="x-litellm-api-key: Bearer sk-1234"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="block text-xs font-bold text-gray-500 uppercase">Model List (one per line)</label>
                      <button 
                        onClick={fetchModels}
                        disabled={isFetchingModels}
                        className="flex items-center gap-1 text-[10px] font-bold text-indigo-600 hover:text-indigo-700 uppercase tracking-wider transition-colors disabled:opacity-50"
                      >
                        {isFetchingModels ? <Loader2 className="w-3 h-3 animate-spin" /> : <List className="w-3 h-3" />}
                        Fetch Models
                      </button>
                    </div>
                    <textarea 
                      value={modelList}
                      onChange={(e) => setModelList(e.target.value)}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all min-h-[120px] font-mono leading-relaxed"
                      placeholder="myGemma3&#10;myGroq&#10;myOpenrouter"
                    />
                  </div>

                  <div className="pt-2">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-100">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${isParallel ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-200 text-gray-500'}`}>
                          <Zap className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-sm font-semibold">Parallel Mode</p>
                          <p className="text-[10px] text-gray-500 uppercase font-bold">Concurrent requests</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <input 
                          type="checkbox" 
                          checked={isParallel}
                          onChange={(e) => setIsParallel(e.target.checked)}
                          className="w-5 h-5 rounded-md border-gray-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                        />
                        {isParallel && (
                          <input 
                            type="number" 
                            value={parallelCount}
                            onChange={(e) => setParallelCount(parseInt(e.target.value) || 1)}
                            className="w-12 py-1 text-center bg-white border border-gray-200 rounded-lg text-sm font-bold focus:ring-2 focus:ring-indigo-500/20 outline-none"
                            min="1"
                            max="10"
                          />
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </section>

          <section className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <button 
              onClick={() => toggleSection('prompt')}
              className="w-full flex items-center justify-between p-6 text-gray-900 font-semibold hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4" />
                <h2>Prompt</h2>
              </div>
              {collapsed.prompt ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronUp className="w-4 h-4 text-gray-400" />}
            </button>

            <AnimatePresence>
              {!collapsed.prompt && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="px-6 pb-6 border-t border-gray-50 pt-4"
                >
                  <textarea 
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all min-h-[150px] leading-relaxed"
                    placeholder="Enter your prompt here..."
                  />
                  <div className="mt-6 flex gap-3">
                    <button 
                      onClick={generateResults}
                      disabled={isGenerating || !prompt.trim() || !modelList.trim()}
                      className="flex-1 bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 text-white font-bold py-3.5 px-6 rounded-xl shadow-lg shadow-indigo-200 transition-all flex items-center justify-center gap-2 group"
                    >
                      {isGenerating ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <Play className="w-5 h-5 group-hover:scale-110 transition-transform" />
                      )}
                      Generate
                    </button>
                    <button 
                      onClick={clearResults}
                      className="p-3.5 bg-white border border-gray-200 text-gray-400 hover:text-red-500 hover:border-red-100 hover:bg-red-50 transition-all rounded-xl"
                      title="Clear Results"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </section>

          <section className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <button 
              onClick={() => toggleSection('history')}
              className="w-full flex items-center justify-between p-6 text-gray-900 font-semibold hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center gap-2">
                <History className="w-4 h-4" />
                <h2>History</h2>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-gray-100 text-gray-500 text-[10px] font-black uppercase rounded-md">
                  {history.length}
                </span>
                {collapsed.history ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronUp className="w-4 h-4 text-gray-400" />}
              </div>
            </button>

            <AnimatePresence>
              {!collapsed.history && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="px-6 pb-6 border-t border-gray-50 pt-4"
                >
                  <div className="flex gap-2 mb-4">
                    <button 
                      onClick={exportHistory}
                      className="flex-1 flex items-center justify-center gap-2 py-2 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-xl text-xs font-bold text-gray-600 transition-all"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Export
                    </button>
                    <label className="flex-1 flex items-center justify-center gap-2 py-2 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-xl text-xs font-bold text-gray-600 transition-all cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      Import
                      <input type="file" accept=".json" onChange={importHistory} className="hidden" />
                    </label>
                  </div>

                  <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                    {history.length === 0 ? (
                      <div className="py-8 text-center text-gray-400">
                        <p className="text-xs">No history yet</p>
                      </div>
                    ) : (
                      history.map((entry) => (
                        <div 
                          key={entry.id}
                          onClick={() => loadHistoryEntry(entry)}
                          className="group p-3 bg-gray-50 hover:bg-indigo-50 border border-gray-100 hover:border-indigo-100 rounded-xl transition-all cursor-pointer relative"
                        >
                          <div className="flex items-start justify-between mb-1">
                            <div className="flex items-center gap-1.5 text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                              <Calendar className="w-3 h-3" />
                              {new Date(entry.timestamp).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                            </div>
                            <button 
                              onClick={(e) => deleteHistoryEntry(entry.id, e)}
                              className="opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-red-500 transition-all"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                          <p className="text-xs font-medium text-gray-700 line-clamp-2 leading-relaxed">
                            {entry.prompt}
                          </p>
                          <div className="mt-2 flex items-center justify-between">
                            <div className="flex -space-x-1.5 overflow-hidden">
                              {entry.results.slice(0, 3).map((r, i) => (
                                <div 
                                  key={i}
                                  className={`w-4 h-4 rounded-full border-2 border-white flex items-center justify-center text-[6px] font-black text-white ${
                                    r.status === 'success' ? 'bg-emerald-500' : 'bg-red-500'
                                  }`}
                                  title={r.modelName}
                                >
                                  {r.modelName[0].toUpperCase()}
                                </div>
                              ))}
                              {entry.results.length > 3 && (
                                <div className="w-4 h-4 rounded-full border-2 border-white bg-gray-200 flex items-center justify-center text-[6px] font-black text-gray-500">
                                  +{entry.results.length - 3}
                                </div>
                              )}
                            </div>
                            <ChevronRight className="w-3 h-3 text-gray-300 group-hover:text-indigo-400 transition-colors" />
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </section>
        </div>

        {/* Results Display */}
        <div className="lg:col-span-8">
          {results.length === 0 ? (
            <div className="h-full min-h-[400px] flex flex-col items-center justify-center text-center p-12 bg-white rounded-3xl border border-dashed border-gray-200">
              <div className="w-16 h-16 bg-gray-50 rounded-2xl flex items-center justify-center mb-4">
                <Cpu className="text-gray-300 w-8 h-8" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">No results yet</h3>
              <p className="text-sm text-gray-500 max-w-xs mt-2">Configure your endpoint and models, then click generate to see comparisons.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Results Top Bar & View Mode Switcher */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-gray-100">
                <div className="flex items-center gap-3">
                  <h2 className="text-lg font-bold flex items-center gap-2">
                    Results
                    <span className="px-2 py-0.5 bg-indigo-100 text-indigo-700 text-[10px] font-black uppercase rounded-md">
                      {results.length} Models
                    </span>
                  </h2>

                  {/* View Mode Switcher */}
                  <div className="flex items-center p-1 bg-gray-100 rounded-xl text-xs font-semibold text-gray-600">
                    <button
                      onClick={() => setViewMode("split")}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                        viewMode === "split" 
                          ? "bg-white text-indigo-700 shadow-xs font-bold" 
                          : "hover:text-gray-900"
                      }`}
                      title="Show both Waterfall Timeline and Response Cards"
                    >
                      <Layers className="w-3.5 h-3.5" />
                      <span>Split</span>
                    </button>
                    <button
                      onClick={() => setViewMode("waterfall")}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                        viewMode === "waterfall" 
                          ? "bg-white text-indigo-700 shadow-xs font-bold" 
                          : "hover:text-gray-900"
                      }`}
                      title="DevTools Network Table & Waterfall Timeline"
                    >
                      <Activity className="w-3.5 h-3.5" />
                      <span>DevTools Network</span>
                    </button>
                    <button
                      onClick={() => setViewMode("cards")}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all ${
                        viewMode === "cards" 
                          ? "bg-white text-indigo-700 shadow-xs font-bold" 
                          : "hover:text-gray-900"
                      }`}
                      title="Cards View with Embedded DevTools Timing"
                    >
                      <LayoutGrid className="w-3.5 h-3.5" />
                      <span>Cards</span>
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-gray-200" /> Idle
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-amber-400" /> Pending
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-emerald-400" /> Success
                  </div>
                </div>
              </div>

              {/* DevTools Network Waterfall Panel (Visible in 'split' and 'waterfall' modes) */}
              {(viewMode === "split" || viewMode === "waterfall") && (
                <div className="space-y-2">
                  <NetworkWaterfallPanel 
                    results={results} 
                    selectedId={selectedResultId}
                    onSelectResult={(id) => {
                      setSelectedResultId(id);
                      if (viewMode === "waterfall") {
                        setViewMode("split");
                      }
                      setTimeout(() => {
                        const el = document.getElementById(id);
                        if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
                      }, 100);
                    }}
                  />
                </div>
              )}

              {/* Response Cards Grid (Visible in 'split' and 'cards' modes) */}
              {(viewMode === "split" || viewMode === "cards") && (
                <div className="grid grid-cols-1 gap-6">
                  <AnimatePresence mode="popLayout">
                    {results.map((result, index) => (
                      <motion.div
                        id={result.id}
                        key={result.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ duration: 0.3, delay: index * 0.05 }}
                        className={`bg-white rounded-2xl border transition-all overflow-hidden ${
                          selectedResultId === result.id ? 'ring-2 ring-indigo-500 border-indigo-200 shadow-md' :
                          result.status === 'pending' ? 'border-amber-200 shadow-lg shadow-amber-50 ring-1 ring-amber-100' : 
                          result.status === 'success' ? 'border-gray-100 shadow-sm' : 
                          result.status === 'error' ? 'border-red-100 shadow-sm' : 
                          'border-gray-100 opacity-60'
                        }`}
                      >
                        {/* Card Header */}
                        <div className="px-5 py-4 border-b border-gray-50 flex items-center justify-between bg-white">
                          <div className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold ${
                              result.status === 'pending' ? 'bg-amber-100 text-amber-600' : 
                              result.status === 'success' ? 'bg-emerald-100 text-emerald-600' : 
                              result.status === 'error' ? 'bg-red-100 text-red-600' : 
                              'bg-gray-100 text-gray-400'
                            }`}>
                              {index + 1}
                            </div>
                            <div>
                              <h3 className="font-bold text-sm font-mono">{result.modelName}</h3>
                              <div className="flex items-center gap-2 mt-0.5">
                                {result.status === 'pending' && (
                                  <span className="flex items-center gap-1 text-[10px] font-bold text-amber-500 uppercase">
                                    <RefreshCw className="w-2.5 h-2.5 animate-spin" /> Processing
                                  </span>
                                )}
                                {result.status === 'success' && (
                                  <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-500 uppercase">
                                    <CheckCircle2 className="w-2.5 h-2.5" /> Completed
                                  </span>
                                )}
                                {result.status === 'error' && (
                                  <span className="flex items-center gap-1 text-[10px] font-bold text-red-500 uppercase">
                                    <AlertCircle className="w-2.5 h-2.5" /> Failed
                                  </span>
                                )}
                                {result.status === 'idle' && (
                                  <span className="text-[10px] font-bold text-gray-400 uppercase">Waiting</span>
                                )}
                              </div>
                            </div>
                          </div>

                          {result.status === 'success' && (
                            <button 
                              onClick={() => copyToClipboard(result.output)}
                              className="p-2 hover:bg-gray-50 rounded-lg text-gray-400 hover:text-indigo-600 transition-colors"
                              title="Copy Output"
                            >
                              <Copy className="w-4 h-4" />
                            </button>
                          )}
                        </div>

                        {/* Card Body */}
                        <div className="p-5">
                          {result.status === 'idle' && (
                            <div className="py-8 flex flex-col items-center justify-center text-gray-300">
                              <Clock className="w-8 h-8 mb-2 opacity-20" />
                              <p className="text-xs font-medium">Queued for processing</p>
                            </div>
                          )}

                          {result.status === 'pending' && (
                            <div className="space-y-3">
                              <div className="h-4 bg-gray-100 rounded-md w-3/4 animate-pulse" />
                              <div className="h-4 bg-gray-100 rounded-md w-full animate-pulse" />
                              <div className="h-4 bg-gray-100 rounded-md w-5/6 animate-pulse" />
                            </div>
                          )}

                          {result.status === 'success' && (
                            <div className="space-y-4">
                              <div className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap font-medium">
                                {result.output}
                              </div>
                              
                              {/* DevTools Network Timing & Metrics Component */}
                              <DevToolsTimingDetail result={result} />
                            </div>
                          )}

                          {result.status === 'error' && (
                            <div className="space-y-4">
                              <div className="p-4 bg-red-50 rounded-xl border border-red-100 flex gap-3">
                                <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
                                <div>
                                  <p className="text-sm font-bold text-red-700">Request Failed</p>
                                  <p className="text-xs text-red-600 mt-0.5 leading-relaxed">{result.error}</p>
                                </div>
                              </div>

                              {/* Still show DevTools network failure timing */}
                              {result.metrics && <DevToolsTimingDetail result={result} />}
                            </div>
                          )}
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              )}
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-gray-100 mt-12">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2 text-gray-400">
            <Terminal className="w-4 h-4" />
            <span className="text-xs font-medium">Ollama & vLLM Compatible Benchmarking Tool</span>
          </div>
          <div className="flex items-center gap-6 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
            <a href="#" className="hover:text-indigo-600 transition-colors">Documentation</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">API Reference</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">Privacy</a>
          </div>
        </div>
      </footer>

      {/* Model Selector Modal */}
      <AnimatePresence>
        {showModelSelector && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowModelSelector(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden"
            >
              <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-white sticky top-0 z-10">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-indigo-50 rounded-lg flex items-center justify-center">
                    <List className="w-4 h-4 text-indigo-600" />
                  </div>
                  <h3 className="font-bold text-gray-900">Select Models</h3>
                </div>
                <button 
                  onClick={() => setShowModelSelector(false)}
                  className="p-2 hover:bg-gray-100 rounded-full text-gray-400 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 space-y-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input 
                    type="text" 
                    value={modelSearch}
                    onChange={(e) => setModelSearch(e.target.value)}
                    placeholder="Filter models..."
                    className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all"
                    autoFocus
                  />
                </div>

                <div className="max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                  {availableModels
                    .filter(m => m.toLowerCase().includes(modelSearch.toLowerCase()))
                    .map((model) => {
                      const isSelected = modelList.split("\n").map(m => m.trim()).includes(model);
                      return (
                        <button
                          key={model}
                          onClick={() => addModel(model)}
                          className={`w-full flex items-center justify-between p-3 mb-2 rounded-xl border transition-all text-left group ${
                            isSelected 
                              ? 'bg-indigo-50 border-indigo-100 text-indigo-700' 
                              : 'bg-white border-gray-100 hover:border-indigo-200 text-gray-700'
                          }`}
                        >
                          <span className="text-sm font-mono truncate">{model}</span>
                          {isSelected ? (
                            <CheckCircle2 className="w-4 h-4 text-indigo-500" />
                          ) : (
                            <Plus className="w-4 h-4 text-gray-300 group-hover:text-indigo-400" />
                          )}
                        </button>
                      );
                    })}
                  {availableModels.length === 0 && (
                    <div className="py-12 text-center text-gray-400">
                      <p className="text-sm">No models found</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 flex justify-end">
                <button 
                  onClick={() => setShowModelSelector(false)}
                  className="px-6 py-2 bg-indigo-600 text-white text-sm font-bold rounded-xl hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100"
                >
                  Done
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
